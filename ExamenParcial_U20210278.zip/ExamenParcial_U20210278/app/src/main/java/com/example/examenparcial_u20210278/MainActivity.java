package com.example.examenparcial_u20210278;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

/* ---------------------- LUIS ANDERSON RAMIREZ MARQUEZ-----------------------------
* ---------------------------------- U20210278 ------------------------------------*/
private ImageView PortadaCancion;
private TextView NombreCancion;
private TextView NombreReproduccion;
private TextView Artistas;
private ImageView StopMusic;
private MediaPlayer mediaPlayer;
    // Arrays con los datos de las canciones
    private int[] ImagenesCancion = {R.drawable.believer,R.drawable.fedupp,R.drawable.humann,R.drawable.mercuryy,R.drawable.thunder};
    private String[] nombresCanciones = {"Believer", "Fed Up", "Human", "Mercury", "Thunder"};
    private String[] nombresArtistas = {"Imagine Dragon ", "Ghostemane", "Rag'n'Bone Man", "Ghostemane","Imagine Dragon"};
    private int[] cancionesRaw = {R.raw.believerr, R.raw.fedup, R.raw.humann,R.raw.mercury,R.raw.thunderr};



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        PortadaCancion = findViewById(R.id.imgPortada);
        NombreCancion = findViewById(R.id.txtTitulo);
        NombreReproduccion = findViewById(R.id.txtNombreCancion);
        Artistas = findViewById(R.id.txtCantante);
        StopMusic = findViewById(R.id.imgStop);


        StopMusic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                detenerMusica();
            }
        });

      //  DetallesMusica = findViewById(R.id.playBelieve);

        // Asociar un evento de clic a cada botón de reproducción de música
        findViewById(R.id.playBeliever).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarDetallesCancion(0); // Mostrar detalles de la canción Believer
                reproducirMusica(0); // Reproducir la canción Believer

            }
        });

        findViewById(R.id.playFedUp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarDetallesCancion(1); // Mostrar detalles de la canción Fed Up
                reproducirMusica(1); // Reproducir la canción Fed Up

            }
        });
        findViewById(R.id.playHuman).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarDetallesCancion(2); // Mostrar detalles de la canción Human
                reproducirMusica(2); // Reproducir la canción Human
            }
        });
        findViewById(R.id.playMercury).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarDetallesCancion(3); // Mostrar detalles de la canción Mercury
                reproducirMusica(3); // Reproducir la canción Mercury
            }
        });

        findViewById(R.id.playThunder).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarDetallesCancion(4); // Mostrar detalles de la canción Thunder
                reproducirMusica(4); // Reproducir la canción Thunder
            }
        });

            }

    private void detenerMusica() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.stop(); // Detener la reproducción de la música si se está reproduciendo
            mediaPlayer.release(); // Liberar los recursos del MediaPlayer
            mediaPlayer = null;
            // Ocultar el botón de detener la música
            //StopMusic.setVisibility(View.GONE);
        }
    }

    private void reproducirMusica(int indiceCancion) {
        if (mediaPlayer != null) {
            mediaPlayer.release(); // Liberar recursos si hay un MediaPlayer en uso
        }
        mediaPlayer = MediaPlayer.create(this, cancionesRaw[indiceCancion]);
        mediaPlayer.start(); // Comenzar la reproducción de la música

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release(); // Liberar recursos cuando se destruya la actividad
        }
        // Ocultar el botón de detener la música al destruir la actividad
        //StopMusic.setVisibility(View.GONE);

    }

    private void mostrarDetallesCancion(int indiceCancion) {
        // Mostrar la portada de la canción
        int idPortada = getResources().getIdentifier(String.valueOf(ImagenesCancion[indiceCancion]), "drawable", getPackageName());
        PortadaCancion.setImageResource(idPortada);

        // Mostrar el nombre de la canción y el nombre del artista junto con el nombre de reproduccion
        NombreCancion.setText(nombresCanciones[indiceCancion]);
        Artistas.setText(nombresArtistas[indiceCancion]);
        NombreReproduccion.setText(nombresCanciones[indiceCancion]);

        // Mostrar el botón de detener la música
        StopMusic.setVisibility(View.VISIBLE);
        StopMusic.setImageResource(R.drawable.detener);
    }

}